#pragma once
#ifndef __sampling_h__
#define __sampling_h__

#include "Core\FeimosRender.h"
#include "Core\Geometry.h"
#include "Core\Transform.h"
#include "Sampler\RNG.h"
#include <vector>
#include <iostream>

namespace Feimos {


// Sampling Declarations
void StratifiedSample1D(float *samples, int nsamples, RNG &rng,
	bool jitter = true);

void StratifiedSample2D(Point2f *samples, int nx, int ny, RNG &rng,
	bool jitter = true);

void LatinHypercube(float *samples, int nSamples, int nDim, RNG &rng);

Point2f RejectionSampleDisk(RNG &rng);

Vector3f UniformSampleHemisphere(const Point2f &u);

float UniformHemispherePdf();

Vector3f UniformSampleSphere(const Point2f &u);

float UniformSpherePdf();

Vector3f UniformSampleCone(const Point2f &u, float thetamax);

Vector3f UniformSampleCone(const Point2f &u, float thetamax, const Vector3f &x,
	const Vector3f &y, const Vector3f &z);

float UniformConePdf(float thetamax);

Point2f UniformSampleDisk(const Point2f &u);

Point2f ConcentricSampleDisk(const Point2f &u);

Point2f UniformSampleTriangle(const Point2f &u);

// Sampling Inline Functions
template <typename T>
void Shuffle(T *samp, int count, int nDimensions, RNG &rng) {
	for (int i = 0; i < count; ++i) {
		int other = i + rng.UniformUInt32(count - i);
		for (int j = 0; j < nDimensions; ++j)
			std::swap(samp[nDimensions * i + j], samp[nDimensions * other + j]);
	}
}

inline Vector3f CosineSampleHemisphere(const Point2f &u) {
	Point2f d = ConcentricSampleDisk(u);
	float z = std::sqrt(std::max((float)0, 1 - d.x * d.x - d.y * d.y));
	return Vector3f(d.x, d.y, z);
}

inline float CosineHemispherePdf(float cosTheta) { return cosTheta * InvPi; }

inline float BalanceHeuristic(int nf, float fPdf, int ng, float gPdf) {
	return (nf * fPdf) / (nf * fPdf + ng * gPdf);
}

inline float PowerHeuristic(int nf, float fPdf, int ng, float gPdf) {
	float f = nf * fPdf, g = ng * gPdf;
	return (f * f) / (f * f + g * g);
}



struct Distribution1D {
	// Distribution1D Public Methods
	Distribution1D(const float *f, int n) : func(f, f + n), cdf(n + 1) {
		// Compute integral of step function at $x_i$
		cdf[0] = 0;
		for (int i = 1; i < n + 1; ++i) cdf[i] = cdf[i - 1] + func[i - 1] / n;

		// Transform step function integral into CDF
		funcInt = cdf[n];
		if (funcInt == 0) {
			for (int i = 1; i < n + 1; ++i) cdf[i] = float(i) / float(n);
		}
		else {
			for (int i = 1; i < n + 1; ++i) cdf[i] /= funcInt;
		}
	}
	int Count() const { return (int)func.size(); }
	float SampleContinuous(float u, float *pdf, int *off = nullptr) const {
		// Find surrounding CDF segments and _offset_
		int offset = FindInterval((int)cdf.size(),
			[&](int index) { return cdf[index] <= u; });
		if (off) *off = offset;
		// Compute offset along CDF segment
		float du = u - cdf[offset];
		if ((cdf[offset + 1] - cdf[offset]) > 0) {
			//CHECK_GT(cdf[offset + 1], cdf[offset]);
			du /= (cdf[offset + 1] - cdf[offset]);
		}
		DCHECK(!std::isnan(du));

		// Compute PDF for sampled offset
		if (pdf) *pdf = (funcInt > 0) ? func[offset] / funcInt : 0;

		// Return $x\in{}[0,1)$ corresponding to sample
		return (offset + du) / Count();
	}
	int SampleDiscrete(float u, float *pdf = nullptr,
		float *uRemapped = nullptr) const {
		// Find surrounding CDF segments and _offset_
		int offset = FindInterval((int)cdf.size(),
			[&](int index) { return cdf[index] <= u; });
		if (pdf) *pdf = (funcInt > 0) ? func[offset] / (funcInt * Count()) : 0;
		if (uRemapped)
			*uRemapped = (u - cdf[offset]) / (cdf[offset + 1] - cdf[offset]);
		//if (uRemapped) CHECK(*uRemapped >= 0.f && *uRemapped <= 1.f);
		return offset;
	}
	float DiscretePDF(int index) const {
		//CHECK(index >= 0 && index < Count());
		return func[index] / (funcInt * Count());
	}

	// Distribution1D Public Data
	std::vector<float> func, cdf;
	float funcInt;
};

class Distribution2D {
public:
	// Distribution2D Public Methods
	Distribution2D(const float *data, int nu, int nv);
	Point2f SampleContinuous(const Point2f &u, float *pdf) const {
		float pdfs[2];
		int v;
		float d1 = pMarginal->SampleContinuous(u[1], &pdfs[1], &v);
		float d0 = pConditionalV[v]->SampleContinuous(u[0], &pdfs[0]);
		*pdf = pdfs[0] * pdfs[1];
		return Point2f(d0, d1);
	}
	float Pdf(const Point2f &p) const {
		int iu = Clamp(int(p[0] * pConditionalV[0]->Count()), 0,
			pConditionalV[0]->Count() - 1);
		int iv =
			Clamp(int(p[1] * pMarginal->Count()), 0, pMarginal->Count() - 1);
		return pConditionalV[iv]->func[iu] / pMarginal->funcInt;
	}

private:
	// Distribution2D Private Data
	std::vector<std::unique_ptr<Distribution1D>> pConditionalV;
	std::unique_ptr<Distribution1D> pMarginal;
};



}



#endif



